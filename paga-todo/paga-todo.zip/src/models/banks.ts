export interface Banks {
    id: number;
    description: string;
    age: string;
    url: string;
    bankName: string;
}